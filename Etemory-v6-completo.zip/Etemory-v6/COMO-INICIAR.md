# ETEMORY 6 — Instalação e execução

## Uso imediato no Windows

1. Instale **Node.js 24 LTS ou superior** em https://nodejs.org/.
2. Extraia o ZIP em uma pasta normal (não execute dentro do ZIP).
3. Dê dois cliques em **`INICIAR-ETEMORY-WINDOWS.bat`**.
4. Abra **http://127.0.0.1:8080** no mesmo computador.
5. Crie sua conta com e-mail e senha; o banco real estará em `data/etemory.sqlite`.

Para explorar sem criar sua conta, feche a janela anterior e execute `TESTAR-DEMONSTRACAO-WINDOWS.bat`. Clique em **Conhecer a demonstração** na tela de login. O modo de exemplo guarda seus dados apenas em `data-demo/`, separado da instalação normal.

A interface já está compilada na pasta `dist/`: não é necessário usar npm para executar o servidor e a interface no computador.

## Terminal (Windows, Linux, macOS)

```bash
node server/start.mjs
```

Para reconstruir os arquivos web após mudanças no código-fonte:

```bash
npm ci
npm run build
npm test
```

## Android — gerar APK de teste

Requisitos: Android Studio, SDK Android 36, **JDK 21**, Node.js 24+, Gradle Wrapper incluso. Garanta `JAVA_HOME` apontando para JDK 21. O pacote NÃO inclui um APK já compilado.

```bash
npm ci
npm run android:apk
```

Se as dependências, Android SDK e Gradle estiverem instalados corretamente, o script copia o APK de teste para `output/Etemory-v6-debug.apk`. A instalação no celular não cria servidor: conecte-o a uma instância privada do Etemory. Durante testes na mesma rede Wi-Fi, informe no app `http://IP_DO_PC:8080` e inicie o servidor com `HOST=0.0.0.0` (somente em rede de confiança). No Windows, pode ser necessário liberar a porta no firewall. Não exponha HTTP ou modo de demonstração à internet.

**IMPORTANTE:** Produção exige servidor com HTTPS válido, hospedagem, backup, controle operacional e assinatura do aplicativo. Não use uma instalação local no celular como se fosse um servidor online.

## iOS — preparar IPA

Requer macOS, Xcode, Node.js 24+, conta de desenvolvimento/perfil de provisionamento quando aplicável.

```bash
npm ci
npm run build
npx cap sync ios
npx cap open ios
```

No Xcode, configure *Signing & Capabilities*, o `Bundle ID` e faça Archive/Distribute. Um arquivo IPA assinado **não** foi gerado neste ambiente. A sessão usa armazenamento seguro no aplicativo nativo existente.

## Dados e migração

Esta versão foi desenvolvida a partir do código do Etemory v5 recuperado do ZIP original. **Não modificamos Firebase, Cloudinary, hospedagens externas ou outros serviços de produção**. O banco SQLite local começa vazio. Se já há uma instalação SQLite da v5, faça backup do diretório de dados antes de atualizar e teste a compatibilidade numa cópia. Não substitua dados reais sem validar a migração.

## Segurança e operações

- Senhas: hash scrypt e sal aleatório; sessões expiram e são revogáveis.
- Perfil, seguidores, bloqueio e três níveis de visibilidade controlados pela API.
- Upload: verifica assinaturas de formato e limita 30 MB por arquivo/500 MB por conta.
- Excluir memória: primeiro lixeira (recuperável), depois confirmação por texto para remoção definitiva.
- Mensagens privadas **não são criptografadas de ponta a ponta**; administrador do servidor pode acessá-las.
- Sem push notifications, redefinição de senha por e-mail, painel de moderação completo, entrega CDN, cache offline abrangente ou vídeo transcodificado.
- Planeje backup do banco **e do diretório de mídia**. Exportar JSON não faz backup completo de imagens.
