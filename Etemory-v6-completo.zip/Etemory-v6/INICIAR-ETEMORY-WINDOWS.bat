@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Instale o Node.js 24 ou superior antes de iniciar. & pause & exit /b 1)
echo Etemory 6 - iniciando servidor local com banco persistente...
echo Abra http://127.0.0.1:8080 no navegador.
node server/start.mjs
pause
