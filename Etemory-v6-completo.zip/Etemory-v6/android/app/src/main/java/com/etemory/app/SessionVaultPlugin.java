package com.etemory.app;
import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.security.KeyStore;
import java.nio.charset.StandardCharsets;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
@CapacitorPlugin(name="SessionVault")
public class SessionVaultPlugin extends Plugin {
 private android.content.SharedPreferences prefs(){return getContext().getSharedPreferences("etemory-vault",Context.MODE_PRIVATE);}
 private SecretKey key() throws Exception {KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);if(!s.containsAlias("etemory.session.v1")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("etemory.session.v1",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").setKeySize(256).build());g.generateKey();}return (SecretKey)s.getKey("etemory.session.v1",null);}
 @PluginMethod public void get(PluginCall call){String value="",saved=prefs().getString("session","");try{if(!saved.isEmpty()){String[] p=saved.split(":");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));value=new String(c.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);}}catch(Exception e){prefs().edit().remove("session").apply();}JSObject r=new JSObject();r.put("value",value);call.resolve(r);}
 @PluginMethod public void set(PluginCall call){String v=call.getString("value","");if(!v.matches("^[A-Za-z0-9_-]{32,128}$")){call.reject("Sessão inválida.");return;}try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());String s=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(v.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);if(!prefs().edit().putString("session",s).commit())throw new Exception();call.resolve();}catch(Exception e){call.reject("Não foi possível proteger a sessão.");}}
 @PluginMethod public void clear(PluginCall call){if(prefs().edit().remove("session").commit())call.resolve();else call.reject("Não foi possível encerrar a sessão local.");}
}
