/**
 * Etemory 6 — editing extension, isolated from the core routing layer.
 * The backend enforces authorship and visibility independently.
 */
const dialog = document.getElementById('edit-dialog');
const nativeSheet = document.getElementById('sheet');
const feelings = ['Saudade','Amor','Paz','Gratidão','Recomeço','Felicidade','Nostalgia','Liberdade','Amizade','Esperança','Melancolia','Superação'];
const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const bridge = () => window.__etemoryBridge;
let editedId = null;
let editBusy = false;
function appendEditButton(button){
 const me = bridge()?.getMe?.();
 const card = button.closest('.post-card');
 if(!me || !card || card.querySelector('.post-head a')?.getAttribute('href') !== `#perfil/${me.id}`) return;
 const id = Number(button.dataset.id);
 if(!Number.isSafeInteger(id) || id < 1) return;
 queueMicrotask(() => {
  const menu = nativeSheet.querySelector('.sheet-menu');
  if(!nativeSheet.open || !menu || menu.querySelector('[data-action="edit-post"]')) return;
  const b=document.createElement('button');b.className='menu-item';b.dataset.action='edit-post';b.dataset.id=String(id);
  b.innerHTML='<span aria-hidden="true" style="font-size:22px;color:var(--wine);width:20px;text-align:center">✎</span>Editar esta memória';
  menu.prepend(b);
 });
}
async function editPost(id){
 if(editBusy) return;
 const {post}=await bridge().api(`/posts/${id}`);
 if(!post?.author?.isMe || post.deletedAt) throw Error('Esta memória não pode ser editada.');
 editedId=id;
 if(nativeSheet.open) nativeSheet.close();
 const checked=new Set(post.emotions);
 dialog.innerHTML=`<header class="sheet-header"><h2 id="edit-title">Editar sua memória</h2><button class="icon-btn" data-edit-close aria-label="Fechar">×</button></header>
 <div class="sheet-body"><p class="field-hint" style="margin-bottom:19px">A foto continua a mesma. Você pode mudar as palavras, os sentimentos e quem pode ver este instante.</p>
 <form id="edit-form"><div class="field"><label for="edit-name">Nome da memória</label><input id="edit-name" name="title" maxlength="90" minlength="1" required value="${escapeHTML(post.title)}"></div>
 <div class="field"><label for="edit-caption">Sua história</label><textarea id="edit-caption" name="caption" maxlength="2200">${escapeHTML(post.caption)}</textarea></div>
 <div class="field"><label>Sentimentos · até três</label><div class="check-chips">${feelings.map(x=>`<label><input type="checkbox" name="emotion" value="${escapeHTML(x)}" ${checked.has(x)?'checked':''}><span>${escapeHTML(x)}</span></label>`).join('')}</div></div>
 <div class="field"><label for="edit-place">Lugar</label><input id="edit-place" name="location" maxlength="80" value="${escapeHTML(post.location)}"></div>
 <div class="field"><label for="edit-visibility">Quem pode ver?</label><select id="edit-visibility" name="visibility">${[['public','Todos na comunidade'],['followers','Meus seguidores'],['private','Só eu']].map(([value,name])=>`<option value="${value}" ${post.visibility===value?'selected':''}>${name}</option>`).join('')}</select></div>
 <p class="edit-feedback" id="edit-feedback" role="alert" aria-live="polite"></p><div class="edit-actions"><button class="button outline" type="button" data-edit-close>Cancelar</button><button class="button" id="edit-save" type="submit">Salvar alterações</button></div></form></div>`;
 dialog.showModal();dialog.querySelector('#edit-name').focus();
}
document.addEventListener('click', async event=>{
 const editButton=event.target.closest('[data-action="edit-post"]');
 if(editButton){event.preventDefault();try{await editPost(Number(editButton.dataset.id));}catch(e){bridge()?.toast?.(e.message);}return;}
 const menuButton=event.target.closest('[data-action="post-menu"]');
 if(menuButton)appendEditButton(menuButton);
 if(event.target.closest('[data-edit-close]'))dialog.close();
});
dialog.addEventListener('change',event=>{
 if(event.target.name!=='emotion')return;
 const checked=dialog.querySelectorAll('input[name="emotion"]:checked');
 if(checked.length>3){event.target.checked=false;dialog.querySelector('#edit-feedback').textContent='Escolha no máximo três sentimentos.';}
});
dialog.addEventListener('submit', async event=>{
 if(event.target.id!=='edit-form')return;
 event.preventDefault();if(editBusy || !editedId)return;
 const data=new FormData(event.target),emotions=data.getAll('emotion');
 if(emotions.length>3)return;
 const save=dialog.querySelector('#edit-save');const feedback=dialog.querySelector('#edit-feedback');editBusy=true;save.disabled=true;save.textContent='Salvando…';feedback.textContent='';
 try{
  await bridge().api(`/posts/${editedId}`,'PATCH',{title:data.get('title'),caption:data.get('caption'),location:data.get('location'),visibility:data.get('visibility'),emotions});
  dialog.close();editedId=null;await bridge().refresh();bridge().toast('Memória atualizada com carinho.');
 }catch(e){feedback.textContent=e.message;}
 finally{editBusy=false;save.disabled=false;save.textContent='Salvar alterações';}
});
dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
dialog.addEventListener('close',()=>{editedId=null;});
