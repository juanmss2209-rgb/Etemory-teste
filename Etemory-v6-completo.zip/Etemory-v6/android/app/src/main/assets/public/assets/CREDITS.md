# Imagens e fontes da demonstração

Fotografias de exemplo obtidas no Unsplash e incluídas localmente. Nomes, textos e perfis de demonstração são fictícios; fotografias de retrato são ilustrativas.

- sunset.jpg: https://images.unsplash.com/photo-1470252649378-9c29740c9fa8
- ocean.jpg: https://images.unsplash.com/photo-1507525428034-b723cf961d3e
- mountain.jpg: https://images.unsplash.com/photo-1464822759023-fed622ff2c3b
- flowers.jpg: https://images.unsplash.com/photo-1490750967868-88aa4486c946
- road.jpg: https://images.unsplash.com/photo-1500530855697-b586d89ba3ee
- forest.jpg: https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05
- ana.jpg: https://images.unsplash.com/photo-1494790108377-be9c29b29330
- lucas.jpg: https://images.unsplash.com/photo-1500648767791-00dcc994a43e
- clara.jpg: https://images.unsplash.com/photo-1534528741775-53994a69daeb
- pedro.jpg: https://images.unsplash.com/photo-1506794778202-cad84cf45f1d

Fontes servidas originalmente por Google Fonts: Cormorant Garamond, DM Sans, Nothing You Could Do. Os arquivos incluídos em fonts.css são cópias locais para evitar requisições externas na demonstração.
