import {native} from './api.js';
import {App} from '@capacitor/app';
import {Haptics,ImpactStyle} from '@capacitor/haptics';
import {Keyboard} from '@capacitor/keyboard';
import {StatusBar,Style} from '@capacitor/status-bar';
import {Share} from '@capacitor/share';
import {Filesystem,Directory,Encoding} from '@capacitor/filesystem';
export function haptic(){if(native)Haptics.impact({style:ImpactStyle.Light}).catch(()=>{});}
export async function setupNative(back){if(!native)return;await StatusBar.setStyle({style:Style.Light}).catch(()=>{});Keyboard.addListener('keyboardWillShow',()=>document.body.classList.add('keyboard-open'));Keyboard.addListener('keyboardWillHide',()=>document.body.classList.remove('keyboard-open'));App.addListener('backButton',({canGoBack})=>{if(back())return;if(canGoBack)history.back();else App.minimizeApp();});}
export async function exportData(data){const text=JSON.stringify(data,null,2),name='etemory-meus-dados.json';if(native){const {uri}=await Filesystem.writeFile({path:name,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});await Share.share({title:'Meus dados do Etemory',files:[uri]});return;}const url=URL.createObjectURL(new Blob([text],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
