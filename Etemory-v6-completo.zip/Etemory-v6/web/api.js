import {Capacitor,registerPlugin} from '@capacitor/core';
export const native=Capacitor.isNativePlatform();
const Vault=registerPlugin('SessionVault');
let token='',base=native?localStorage.getItem('etemory.server')||'':'';
export const serverURL=()=>base;
export async function initSession(){if(native){try{token=(await Vault.get()).value||'';}catch{throw Error('Não foi possível abrir o armazenamento seguro. Reabra o aplicativo.');}}}
export async function remember(value){if(native){await Vault.set({value});token=value;}}
export async function forget(){if(native)await Vault.clear();token='';}
export async function setServer(value){
 const u=new URL(value.trim());const local=/^(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)$/.test(u.hostname);
 if(u.username||u.password||u.pathname!=='/'||u.search||u.hash||!(u.protocol==='https:'||(__DEV_NATIVE__&&local&&u.protocol==='http:')))throw Error('Use o endereço HTTPS do servidor, sem caminho. A versão de testes também aceita um IP da rede local.');
 await forget();base=u.origin;localStorage.setItem('etemory.server',base);
}
export const mediaURL=url=>url?(base+url):'';
export async function api(path,method='GET',data){
 if(native&&!base)throw Error('Conecte seu servidor Etemory.');
 const raw=data instanceof Blob,controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),raw?120000:15000);
 try{const r=await fetch(base+'/api'+path,{method,credentials:'include',headers:{'X-Etemory-Client':'app',...(native?{'X-Etemory-Native':'1',...(token?{Authorization:'Bearer '+token}:{})}:{}),...(data!==undefined?{'Content-Type':raw?data.type||'application/octet-stream':'application/json'}:{})},body:data===undefined?undefined:raw?data:JSON.stringify(data),signal:controller.signal});
 const b=await r.json().catch(()=>({error:'O endereço não respondeu como um servidor Etemory.'}));if(!r.ok){const e=Error(b.error||'Não foi possível completar a ação.');e.status=r.status;throw e;}if(b.token)await remember(b.token);return b;
 }catch(e){if(e.name==='AbortError')throw Error('A conexão demorou. Confira sua rede e tente novamente.');if(e instanceof TypeError)throw Error('Sem conexão com o servidor. Confira a rede e o endereço.');throw e;}finally{clearTimeout(timeout);}
}
export async function prepareImage(file){
 if(!file.type.startsWith('image/'))return file;
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Escolha uma foto JPEG, PNG ou WebP.');
 const bitmap=await createImageBitmap(file).catch(()=>{throw Error('Não conseguimos abrir esta foto. Escolha outra.');});
 const scale=Math.min(1,1800/Math.max(bitmap.width,bitmap.height)),canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Não foi possível preparar a foto.')),'image/jpeg',.86));
}
