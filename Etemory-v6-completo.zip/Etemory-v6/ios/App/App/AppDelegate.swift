import UIKit
import Capacitor

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        let config = UISceneConfiguration(name: "Default Configuration",
                                          sessionRole: connectingSceneSession.role)
        config.delegateClass = SceneDelegate.self
        return config
    }
}

import Security
@objc(SessionVaultPlugin)
public class SessionVaultPlugin: CAPPlugin, CAPBridgedPlugin {
 public let identifier = "SessionVaultPlugin"
 public let jsName = "SessionVault"
 public let pluginMethods: [CAPPluginMethod] = [CAPPluginMethod(name: "get", returnType: CAPPluginReturnPromise), CAPPluginMethod(name: "set", returnType: CAPPluginReturnPromise), CAPPluginMethod(name: "clear", returnType: CAPPluginReturnPromise)]
 private var query: [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "com.etemory.app.session", kSecAttrAccount as String: "current"] }
 @objc func get(_ call: CAPPluginCall) {
  var q = query; q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
  var item: CFTypeRef?; let status = SecItemCopyMatching(q as CFDictionary, &item)
  if status == errSecItemNotFound { call.resolve(["value": ""]); return }
  guard status == errSecSuccess, let data = item as? Data, let value = String(data: data, encoding: .utf8) else { call.reject("Não foi possível abrir a sessão segura."); return }
  call.resolve(["value": value])
 }
 @objc func set(_ call: CAPPluginCall) {
  guard let value = call.getString("value"), value.range(of: "^[A-Za-z0-9_-]{32,128}$", options: .regularExpression) != nil, let data = value.data(using: .utf8) else { call.reject("Sessão inválida."); return }
  let attrs: [String: Any] = [kSecValueData as String: data, kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
  var status = SecItemUpdate(query as CFDictionary, attrs as CFDictionary)
  if status == errSecItemNotFound { var q = query; attrs.forEach { q[$0.key] = $0.value }; status = SecItemAdd(q as CFDictionary, nil) }
  if status == errSecSuccess { call.resolve() } else { call.reject("Não foi possível proteger a sessão.") }
 }
 @objc func clear(_ call: CAPPluginCall) { let s = SecItemDelete(query as CFDictionary); if s == errSecSuccess || s == errSecItemNotFound { call.resolve() } else { call.reject("Não foi possível encerrar a sessão.") } }
}
class EtemoryViewController: CAPBridgeViewController {
 override func capacitorDidLoad() { bridge?.registerPluginInstance(SessionVaultPlugin()) }
}
