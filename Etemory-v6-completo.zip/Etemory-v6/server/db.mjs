import { DatabaseSync } from 'node:sqlite';
import { mkdirSync,readFileSync,existsSync,writeFileSync } from 'node:fs';
import {join} from 'node:path';
import {randomBytes,scrypt as derive,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
const scrypt=promisify(derive);
export const hash=x=>createHash('sha256').update(x).digest('hex');
export async function password(value){const salt=randomBytes(16).toString('hex');return salt+':'+Buffer.from(await scrypt(value,salt,64)).toString('hex');}
export async function verify(value,stored='dummy:'){const [salt,key]=stored.split(':');const actual=Buffer.from(await scrypt(value,salt,64)),expected=Buffer.from(key||'00'.repeat(64),'hex');return actual.length===expected.length&&timingSafeEqual(actual,expected);}
export function database(dir){
 mkdirSync(join(dir,'uploads'),{recursive:true,mode:0o700});const key=join(dir,'.media-key');if(!existsSync(key))writeFileSync(key,randomBytes(32),{mode:0o600});
 const db=new DatabaseSync(join(dir,'etemory.sqlite'));db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,handle TEXT UNIQUE NOT NULL,name TEXT NOT NULL,bio TEXT DEFAULT '',avatar_id TEXT,password TEXT NOT NULL,created_at INTEGER NOT NULL,deactivated INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,owner_id TEXT REFERENCES users(id),file TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,title TEXT NOT NULL,caption TEXT DEFAULT '',emotions TEXT DEFAULT '[]',location TEXT DEFAULT '',visibility TEXT DEFAULT 'public',created_at INTEGER NOT NULL,archived INTEGER DEFAULT 0,deleted_at INTEGER);
 CREATE TABLE IF NOT EXISTS post_media(post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,media_id TEXT REFERENCES media(id),position INTEGER,PRIMARY KEY(post_id,media_id));
 CREATE TABLE IF NOT EXISTS likes(user_id TEXT REFERENCES users(id) ON DELETE CASCADE,post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,PRIMARY KEY(user_id,post_id));
 CREATE TABLE IF NOT EXISTS saves(user_id TEXT REFERENCES users(id) ON DELETE CASCADE,post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,PRIMARY KEY(user_id,post_id));
 CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id),post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,text TEXT,created_at INTEGER);
 CREATE TABLE IF NOT EXISTS follows(follower_id TEXT REFERENCES users(id),following_id TEXT REFERENCES users(id),PRIMARY KEY(follower_id,following_id));
 CREATE TABLE IF NOT EXISTS blocks(user_id TEXT REFERENCES users(id),blocked_id TEXT REFERENCES users(id),PRIMARY KEY(user_id,blocked_id));
 CREATE TABLE IF NOT EXISTS albums(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id),name TEXT,created_at INTEGER);
 CREATE TABLE IF NOT EXISTS album_posts(album_id INTEGER REFERENCES albums(id) ON DELETE CASCADE,post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,PRIMARY KEY(album_id,post_id));
 CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,first_id TEXT REFERENCES users(id),second_id TEXT REFERENCES users(id),UNIQUE(first_id,second_id));
 CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,conversation_id INTEGER REFERENCES conversations(id),sender_id TEXT REFERENCES users(id),text TEXT,created_at INTEGER,read_at INTEGER);
 CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id),actor_id TEXT REFERENCES users(id),kind TEXT,post_id INTEGER REFERENCES posts(id) ON DELETE CASCADE,created_at INTEGER,read_at INTEGER);
 CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id),post_id INTEGER REFERENCES posts(id) ON DELETE SET NULL,reason TEXT,created_at INTEGER);
 CREATE INDEX IF NOT EXISTS posts_owner ON posts(user_id,id DESC);CREATE INDEX IF NOT EXISTS comments_post ON comments(post_id,id);CREATE INDEX IF NOT EXISTS messages_thread ON messages(conversation_id,id);CREATE INDEX IF NOT EXISTS notifications_owner ON notifications(user_id,id DESC);CREATE INDEX IF NOT EXISTS follows_target ON follows(following_id);
 `);
 return {db,key:readFileSync(key),q:(sql,...p)=>db.prepare(sql).all(...p),one:(sql,...p)=>db.prepare(sql).get(...p),run:(sql,...p)=>db.prepare(sql).run(...p)};
}
export function check(ok,status,message){if(!ok){const e=new Error(message);e.status=status;throw e;}}
export function text(value,max,min=0){check(typeof value==='string',400,'Confira os campos.');const v=value.trim().replaceAll('\0','');check(v.length>=min&&v.length<=max,400,`Use entre ${min} e ${max} caracteres.`);return v;}
export function pass(value){check(typeof value==='string'&&value.length>=10&&value.length<=128,400,'Use uma senha entre 10 e 128 caracteres.');return value;}
export const feelings=['Saudade','Amor','Paz','Gratidão','Recomeço','Felicidade','Nostalgia','Liberdade','Amizade','Esperança','Melancolia','Superação'];
