import {resolve} from 'node:path';
import {createApp} from './app.mjs';
const app=createApp({dataDir:resolve(process.env.ETEMORY_DATA||'data'),webDir:resolve('dist'),demo:process.env.ETEMORY_DEMO==='1',secure:process.env.ETEMORY_SECURE==='1',trustProxy:process.env.ETEMORY_TRUST_PROXY==='1',origins:(process.env.ETEMORY_ORIGINS||'').split(',').filter(Boolean)});
const port=Number(process.env.PORT||8080),host=process.env.HOST||'127.0.0.1';
app.server.listen(port,host,()=>console.log(`Etemory: http://${host}:${port} — dados: ${process.env.ETEMORY_DATA||'data'}`));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>app.close().then(()=>process.exit(0)));
