await import('./build.mjs');
const args=process.argv.slice(2);const get=(key)=>args[args.indexOf(key)+1];
if(args.includes('--port'))process.env.PORT=get('--port');
if(args.includes('--host'))process.env.HOST=get('--host');
await import('./demo.mjs');
