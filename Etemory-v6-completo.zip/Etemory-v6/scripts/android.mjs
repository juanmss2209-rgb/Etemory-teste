import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,copyFileSync,mkdirSync} from 'node:fs';
const run=(cmd,args,cwd)=>{const r=spawnSync(cmd,args,{cwd,stdio:'inherit',shell:process.platform==='win32'});if(r.status!==0)throw Error('Falha em '+cmd);};
run('npm',['run','build']);run('npx',['cap','sync','android']);
const path='android/app/src/main/assets/capacitor.config.json',original=readFileSync(path,'utf8'),release=process.env.ETEMORY_RELEASE==='1';
try{if(!release){const config=JSON.parse(original);config.server.cleartext=true;config.android.allowMixedContent=true;writeFileSync(path,JSON.stringify(config,null,2));}run(process.platform==='win32'?'gradlew.bat':'./gradlew',[release?'assembleRelease':'assembleDebug','--no-daemon','--console=plain'],'android');mkdirSync('output',{recursive:true});copyFileSync(`android/app/build/outputs/apk/${release?'release':'debug'}/app-${release?'release-unsigned':'debug'}.apk`,`output/Etemory-v6-${release?'unsigned':'debug'}.apk`);}finally{writeFileSync(path,original);}
