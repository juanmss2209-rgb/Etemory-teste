import {resolve} from 'node:path';
import {seed} from '../server/seed.mjs';
process.env.ETEMORY_DATA=resolve('data-demo');process.env.ETEMORY_DEMO='1';
await seed(process.env.ETEMORY_DATA);await import('../server/start.mjs');
