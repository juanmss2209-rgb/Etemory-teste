import {build} from 'esbuild';
import {mkdir,cp,rm} from 'node:fs/promises';
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});
await cp('web/assets','dist/assets',{recursive:true});
for(const f of ['index.html','app.css','enhance.js'])await cp('web/'+f,'dist/'+f);
await build({entryPoints:['web/app.js'],bundle:true,format:'esm',target:['es2022'],minify:true,outfile:'dist/app.js',define:{__DEV_NATIVE__:JSON.stringify(process.env.ETEMORY_RELEASE!=='1')}});
console.log('Interface compilada em dist/.');
