from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
dest=root/'output'/'Etemory-v6-Projeto.zip'
dest.parent.mkdir(exist_ok=True)
skip={'node_modules','output','.git','.gradle','build','DerivedData','data','data-demo','data-test'}
with ZipFile(dest,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for p in root.rglob('*'):
        rel=p.relative_to(root)
        if not p.is_file() or any(x in skip for x in rel.parts): continue
        if p.name in ('local.properties','.DS_Store') or p.suffix in ('.log','.keystore','.jks'): continue
        if p.name.startswith('__qa'): continue
        z.write(p,Path('Etemory-v6')/rel)
print(str(dest),dest.stat().st_size)
