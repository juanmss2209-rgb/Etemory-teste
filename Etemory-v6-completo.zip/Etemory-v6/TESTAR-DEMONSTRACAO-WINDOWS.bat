@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Instale o Node.js 24 ou superior antes de iniciar. & pause & exit /b 1)
echo Demonstração isolada: NÃO altera os dados da instalação principal.
echo Abra http://127.0.0.1:8080 e clique em Conhecer a demonstração.
node scripts/demo.mjs
pause
