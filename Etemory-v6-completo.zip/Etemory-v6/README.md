# Etemory 6.0

Reconstrução independente do Etemory: interface mobile com navegação flutuante, Polaroids, contas e relações sociais persistidas em SQLite, servidor Node.js 24 e aplicativos Capacitor para Android/iOS.

Este pacote é uma cópia de desenvolvimento em andamento. Consulte `VALIDACAO.md` na entrega final para os resultados realmente executados. A base Firebase/Cloudinary anterior não foi migrada nem modificada.

## Executar

Requer Node.js 24 ou superior. O diretório `dist/` já contém a interface compilada.

```sh
node server/start.mjs
```

Abra http://127.0.0.1:8080. Crie sua conta: a instalação nova começa vazia. Para a demonstração isolada, execute `node scripts/demo.mjs` e use o botão da demonstração. Os dados de exemplo usam `data-demo/`; a instalação normal usa `data/`.

Para editar e recompilar: `npm ci` e `npm run build`. Testes: `npm test`.

Nada é publicado automaticamente. O aplicativo móvel precisa de um servidor Etemory acessível. No Android de testes, pode ser um computador na mesma rede. Não use a URL do antigo site como servidor desta versão.

## O que mudou na v6

- Identidade Polaroid + infinito, vermelho borgonha e rosados sólidos; nenhum efeito Liquid Glass.
- Navegação inferior flutuante reforçada, espaços seguros e ações rápidas no celular.
- Edição real de texto, título, sentimentos, local e privacidade das publicações.
- Mantidos perfis, relacionamento social, lixeira e restauração da v5; dados originais não foram migrados nem apagados.

Use Node.js 24+. Em desenvolvimento, o Node.js 22 funciona neste ambiente, mas usa SQLite experimental. Para gerar APK, instale Android Studio com SDK e JDK compatível; rode `npm ci` e `npm run android:apk` na máquina de desenvolvimento. O iOS exige macOS, Xcode e assinatura. A tela do aplicativo mobile precisa se conectar a uma instância de servidor real.
